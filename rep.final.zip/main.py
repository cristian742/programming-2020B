#script:rep.final
from bullet import Password  
def menu_login():
  
  nom = []
  ape = []
  movi = []
  email = ["geovannymunoz742@gmail.com']
  nick = []
  pasww = [123,543]
  estado = []
  print("### Ingreso a la administracion ###")
  print("[1]. Ingresar")
  print("[2]. Crear cuenta")
  print("[3]. salir")
  opt=input("digite una opcion: ")

  if opt =='1': 
   emailp=input("E-mail: ")
   contraseña=input("Contraseña: ") 
   if emailp in email or contraseña in pasww :
    print("ingreso exitoso")
    print("***MENU DE ADMINISTRACION***")
    categorias = []
    proveedores = []
    productos = []
    clientes=[]
    reportes=[]
    print("[1]. categorias")
    print("[2]. proveedores")
    print("[3]. productos")
    print("[4]- clientes")
    print("[5]. reportes")
    opt1=input("digite una opcion")
    if opt1 == '1' : 
      categoria1=input("ingresar nueva categoria")
      categorias.append(categoria1)
      print(categorias)
      
)

'''
print(list[0].split(sep=','))
print(list[1].split(sep=','))
print(len(list[0].split(sep=',')))
print(len(list[1].split(sep=',')))
print("\n")
print(list[0])
print(list[0].split(sep=','))
print(list[0][0].spl
print(list[0][1].split(sep=','))
print(list[0][2].split(sep=','))
print(list[0][3].split(sep=','))
'''
'''
print("\n::: INTERSECCIÓN ::: \n")
i=0
while i < len(list[0].split(sep=',')) :
  j=0
  while j < len(list[1].split(sep=',')) :
    if list[0][i].split(sep=',') == list [1][j].split(sep=',') :
      print (list[0][i].split(sep=','))
    j+=1
  i+=1    
  '''