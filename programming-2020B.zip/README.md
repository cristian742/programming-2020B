# programming-2020B
Repositorio de codigo fuente para el aprendizaje y fortalecimiento del pensamiento algorítmico y computacional en el espacio académico de introducción a la programación
