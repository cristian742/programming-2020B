#script:rep.final
from bullet import Password  
def menu_login():
  
  nom = []
  ape = []
  movi = []
  email = ["geovannymunoz742@gmail.com']
  nick = []
  pasww = [123,543]
  estado = []
  print("### Ingreso a la administracion ###")
  print("[1]. Ingresar")
  print("[2]. Crear cuenta")
  print("[3]. salir")
  opt=input("digite una opcion: ")

  if opt =='1': 
   emailp=input("E-mail: ")
   contraseña=input("Contraseña: ") 
   if emailp in email or contraseña in pasww :
    print("ingreso exitoso")
    print("***MENU DE ADMINISTRACION***")
    categorias = []
    proveedores = []
    productos = []
    clientes=[]
    reportes=[]
    print("[1]. categorias")
    print("[2]. proveedores")
    print("[3]. productos")
    print("[4]- clientes")
    print("[5]. reportes")
    opt1=input("digite una opcion")
    if opt1 == '1' : 
      categoria1=input("ingresar nueva categoria")
      categorias.append(categoria1)
      print(categorias)
      


      


 











   else :
    print("datos invalidos")  
  elif opt == '2' :
   print("formulario de registro")
   nombre = input("ingrese su primer nombre: " ) 
   apellido = input("ingrese su primer apellido: ")
   celular = input("digite su numero de celular: ")
   email1=input("digite su correo: ")
   while email1 in email :
     print ("el correo ya se encuentra registrado")
     email1=input("digite su correo: ")
   nickname = input("ingrese su nickname: ")
   while email1 in email :
     print ("el nickname ya se encuentra registrado")
     nick=input("digite su nickname: ")
   contraseña = Password("Contraseña: ")
   p= contraseña.launch()
   
   
   nom.append(nombre)
   ape.append(apellido)
   movi.append(celular)
   email.append(email1)
   nick.append(nickname)
   pasww.append(contraseña)
   estado.append(True)

  else  :
    print("vuelve pronto, ")  

  print(nom,"\n",ape,"\n",movi,"\n",email,"\n",nick,"\n",pasww,"\n",estado)
  